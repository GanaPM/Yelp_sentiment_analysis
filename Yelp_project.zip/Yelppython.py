#import findspark
#findspark.init()
from pyspark.sql import SparkSession
from pyspark import SparkContext
from pyspark import SparkConf
import pandas as pd

# Initialize SparkContext
sc = SparkContext.getOrCreate()

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("Read JSON Files") \
    .getOrCreate()

# Read the JSON files
spark.read.option("multiline", "true").json("yelp_academic_dataset_business.json")
business = spark.read.json("yelp_academic_dataset_business.json")
review = spark.read.json("yelp_academic_dataset_review.json")
tip = spark.read.json("yelp_academic_dataset_tip.json")
checkin = spark.read.json("yelp_academic_dataset_checkin.json")


# Reading schema of all jsons
print("Schema of Business:")
business.printSchema()
print("First few rows of Business:")
business.show(5)
print(business.count())

tem = business.select("business_id") .distinct()
print(tem.count())


print("Schema of Review:")
review.printSchema()

print("First few rows of Review:")
review.show(5)
print(review.count())

print("Schema of tip:")
review.printSchema()

print("First few rows of tip:")
review.show(5)
print(tip.count())

print("Schema of checkin:")
review.printSchema()

print("First few rows of checkin:")
review.show(5)
print(checkin.count())

# keeping only unique business id's and necessary columns and add index for easy access
from pyspark.sql.functions import col, collect_list

# Step 1: Copy the unique list of business ids in a 'temp' variable
temp = business.select("business_id").distinct()
print(temp.count())

# Step 2: Create a new DataFrame 'review1' having business ids in temp and keep only relevant columns
review1 = review.join(temp, on="business_id", how="inner").select("business_id", "stars", "text")
review1
print(review1.count())

from pyspark.sql import functions as F

# Step 3: Create a new DataFrame 'review2' with index resetting (for future operations on this dataset)
review2 = review1.withColumn("index", F.monotonically_increasing_id())

# Display the first few rows of the DataFrame
review2.show()
print(review2.count())

#pip install vaderSentiment

from pyspark.sql.functions import udf
from pyspark.sql.types import FloatType
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# analysing sentiment in review
analyzer = SentimentIntensityAnalyzer()

def compute_vader_sentiment_score(text):
    # Compute sentiment scores
    sentiment = analyzer.polarity_scores(text)
    # Return compound score (overall sentiment)
    return sentiment['compound']


compute_vader_sentiment_udf = udf(compute_vader_sentiment_score, FloatType())

df = review2.withColumn("sentiment_score", compute_vader_sentiment_udf("text"))
df.head()


# Apply the UDF to create a new column with sentiment polarity
from pyspark.sql.functions import when

# Define a function to categorize sentiment scores into positive, negative, or neutral
def categorize_sentiment(score):
    if score > 0.05:
        return 1
    elif score < -0.05:
        return 0
    else:
        return 2

# Register the function as a UDF
categorize_sentiment_udf = udf(categorize_sentiment)
df_rev = df.withColumn("sentiment_polarity", categorize_sentiment_udf("sentiment_score"))

# Show the DataFrame with the new 'sentiment_polarity' column
review2=df_rev
print("DataFrame with sentiment polarity") 

review2.show()
print(review2.count())

from pyspark.sql.functions import col, lower, contains, rand
from pyspark.sql import Window
print(business.count())

# Action 1: Drop businesses which are not open (is_open == 0)
business = business.filter(col("is_open") == 1)
print(business.count())

# Action 2: Drop businesses which are not in restaurant business (categories do not contain the keyword "food")
business = business.filter(
    lower(col("categories")).contains("food") | 
    lower(col("categories")).contains("restaurants")
)
print(business.count())

# Action 3: Drop businesses with any missing values in critical columns
business = business.dropna(subset=["latitude", "longitude", "stars", "review_count", "city", "state"])
print(business.count())

# Action 4: Create a random stratified sample of restaurants with equal weightage to 'stars' column (distinct count = 9)
window = Window.partitionBy("stars").orderBy(rand())  # Order by a random number
business = business.withColumn("sample", F.row_number().over(window)).filter(col("sample") <= 20).drop("sample")
print(business.count())

# Action 5: Drop unnecessary columns (neighborhood, address, postal_code, is_open, categories) and reindex
business = business.select("business_id", "name","latitude","longitude", "stars", "review_count", "city", "state")
print(business.count())

# Show the resulting DataFrame
print("showing business file after downsizing")
business.show()
print(business.count())

from pyspark.sql.functions import col



from pyspark.sql.functions import sum as sql_sum, col

# def calculate_net_positive_sentiment(review2, business):
# Aggregate the polarity values by business_id
polarity_sum = review2.groupby('business_id').agg(sql_sum('sentiment_polarity').alias('sum_polarity'))

# Join with the business DataFrame to get total_count_of_reviews
net_positive_sentiment = polarity_sum.join(business.select('business_id', 'review_count','city'),
                                               on='business_id', how='inner')

# Calculate net positive sentiment score
net_positive_sentiment = net_positive_sentiment.withColumn('net_positive_sentiment_score',
                                                               col('sum_polarity') / col('review_count'))

# Select only the required columns
net_positive_sentiment = net_positive_sentiment.select('business_id', 'net_positive_sentiment_score')

# return net_positive_sentiment

# Call the function with review2 and business_checkin DataFrames
# net_positive_sentiment = calculate_net_positive_sentiment(review2, business_checkin)

# Show the resulting DataFrame
#print("dataframe merging business with reviews after downsizing businessfile")
#net_positive_sentiment.show()

# net_positive_sentiment.show()
print("net positive sentiment schema : ")
net_positive_sentiment.printSchema()

# Renaming the stars column in both DataFrames to clarify which is which
business_renamed = business.withColumnRenamed("stars", "business_stars")
review2_renamed = review2.withColumnRenamed("stars", "review_stars")

business_renamed.show()
review2_renamed.show()

# Merge DataFrames business review with net_positive sentiment score

# Merge DataFrames business and review2
business_review = business_renamed.join(review2_renamed, on="business_id", how="inner")
print(business_review.count())
# Handle missing values
business_review = business_review.fillna(0)
    
# Selecting columns, ensuring to use 'business_stars' to include the business ratings
business_review = business_review.select(
    "business_id", "name", "latitude", "longitude", "business_stars", "review_count", "city", "state", 
    "text", "index", "sentiment_score", "sentiment_polarity"
)


#business_review.show()




# Joining net_positive_sentiment with business_review on 'business_id'
merged_df = net_positive_sentiment.join(business_review, on='business_id', how='inner')

# Display the schema of the merged DataFrame to understand its structure
merged_df.printSchema()

print("printing final and merged dataframe : ")
#merged_df.show()
print(merged_df.count())

# Count distinct star ratings
distinct_business_stars = merged_df.select("business_stars").distinct().collect()
print("Distinct star ratings in business:", distinct_business_stars)

distinct_business_ids = merged_df.select("business_id").distinct().collect()
print("Distinct star ratings in business:", distinct_business_ids)

# Write the DataFrame to Parquet format
output_dir = "C:/Users/pmgan/Data228/yelp_dataset/merged_df"
merged_df.write.mode("overwrite").parquet(output_dir)

print(f"DataFrame saved to Parquet format at {output_dir}")

# Load the Parquet file back to a Pandas DataFrame
pandas_df = merged_df.toPandas()

# Save as a pickle file
pickle_file = "C:/Users/pmgan/Data228/yelp_dataset/merged_df.pkl"
pandas_df.to_pickle(pickle_file)

print(f"DataFrame saved to Pickle format at {pickle_file}")


######################################################################################






